SJ's Disc Jockey Scheduler V7 — Automatic Zoom Meetings

Adds automatic Zoom creation for:
- Zoom Hangout (30 minutes)
- Zoom Planning Session (60 minutes)

Uses Netlify environment variables:
ZOOM_ACCOUNT_ID
ZOOM_CLIENT_ID
ZOOM_CLIENT_SECRET

Required Zoom scope:
meeting:write:meeting:admin

Flow:
1. Re-check iCloud availability.
2. Create Zoom meeting for Zoom appointment types.
3. Create iCloud event with the Zoom join URL in DESCRIPTION, LOCATION, and URL.
4. Return confirmation to the scheduler.

Phone appointments continue to work without creating Zoom meetings.
