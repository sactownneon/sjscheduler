SJ's Disc Jockey Scheduler V8 — Final Night Cleanup

Included:
- Live iCloud availability checking
- 15-minute appointment buffer
- Real iCloud event creation
- Automatic Zoom meeting creation for Zoom Hangout and Zoom Planning Session
- Zoom join link embedded in Apple Calendar
- Clean success confirmation wording
- Optional confirmation email support

EMAIL:
This build supports confirmation emails through Resend if these Netlify variables are added later:
RESEND_API_KEY
BOOKING_FROM_EMAIL

If those variables are not set, bookings and Zoom still work normally; the email step is skipped safely.

Recommended BOOKING_FROM_EMAIL after domain verification:
SJ's Disc Jockey <appointments@sjsdiscjockey.com>
