SJ's Disc Jockey Scheduler V6 — Real iCloud Booking Test

WHAT THIS ADDS
- The booking form now POSTs to a secure Netlify Function.
- Server re-checks the requested slot against iCloud immediately before booking.
- Creates a confirmed event on Joe's iCloud Calendar.
- Keeps the 15-minute conflict buffer.
- Stores client name, email, phone, and optional note in the event description.
- Zoom is NOT connected yet. Zoom appointment events say that the Zoom link is pending.

TARGET CALENDAR
By default the function writes to the first iCloud calendar named "Calendar".
If the test event lands in the wrong duplicate "Calendar", add this Netlify variable:
APPLE_TARGET_CALENDAR_NUMBER = 2
and redeploy.

TEST
1. Deploy these files to the existing GitHub sjscheduler repo.
2. Book a future "Chat with Joe" test.
3. Confirm it appears in Apple Calendar.
4. Confirm that exact time disappears from the scheduler afterward.
