SJ's Disc Jockey Scheduler V4 — Calendar Debug

This version adds a `busyIntervals` section to the availability JSON response so we can see exactly what start/end time iCloud is reporting for the busy event.

It does not expose event titles or notes.

After deployment, open:
https://sjscheduler.netlify.app/.netlify/functions/availability?date=2026-09-09&duration=30

Look at the bottom for `busyIntervals`.
